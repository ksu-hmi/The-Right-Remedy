# Web_Scraping-WebMD_Scrapy
WebMD scraping, data exploration, and jupyter app for NYCDSA Project 2
